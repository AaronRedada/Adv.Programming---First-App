package com.example.colorcombinationapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemSelectedListener {
        private Spinner spnRed;
        private Spinner spnGreen;
        private Spinner spnBlue;
        private TextView txtNewColor;
        private int red;
        private int green;
        private int blue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);

        spnRed = findViewById(R.id.spn_red);
        spnGreen = findViewById(R.id.spn_green);
        spnBlue = findViewById(R.id.spn_blue);
        txtNewColor = findViewById(R.id.txt_new_color);

        spnRed.setOnItemSelectedListener(this);
        spnGreen.setOnItemSelectedListener(this);
        spnBlue.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if (adapterView.getId() == R.id.spn_red){
            red = (i * 255 / 10);
        }
        else if (adapterView.getId() == R.id.spn_green){
            green = (i * 255 / 10);
        }
        else {
            blue = (i * 255 / 10);
        }
        txtNewColor.setBackgroundColor(Color.rgb(red, green, blue));
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView){
        // n/a
    }

}